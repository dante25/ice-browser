/* Ultimate SN Downloader — Image Host Grabber (page side). Collects every link of the page the way ImageHostGrabber does
   (document.links, javascript-wrapped urls, anonymizers removed, duplicates dropped) and hands them to the extension, which turns each link into an
   image with the host file (direct image links, image host pages, redirects). Injected on demand into pages that are not one of the known sites. */
(function () {
  var IH = {};
  USD.sites.ih = IH;

  IH.match = function () { return /^https?:$/.test(location.protocol); };

  function unanonymize(url) {
    var m = unescape(url).match(/^https?:\/\/.+(https?:\/\/.+)/);
    return m && !/^https?:\/\/[^/]*facebook\.com\//.test(url) ? m[1] : url;
  }

  function collect() {
    var links = [], seen = {};
    function scan(doc) {
      var as = doc.links || [];
      for (var i = 0; i < as.length; i++) {
        var a = as[i], url;
        var wrapped = (a.href || '').match(/javascript.+('|")(http.+?)\1/);
        url = wrapped ? wrapped[2] : a.href;
        if (!url) continue;
        url = unanonymize(url);
        if (!/^https?:\/\//i.test(url) || seen[url]) continue;
        seen[url] = 1;
        links.push({ url: url });
      }
      var frames = doc.querySelectorAll ? doc.querySelectorAll('iframe, frame') : [];
      for (var f = 0; f < frames.length; f++) { try { if (frames[f].contentDocument) scan(frames[f].contentDocument); } catch (e) { /* cross-origin frame */ } }
    }
    scan(document);
    return links;
  }

  IH.describe = function () {
    return { site: 'ih', type: 'page', id: location.hostname, label: document.title || location.hostname, links: collect().length };
  };

  IH.scan = async function (ctx) {
    ctx.status('Collecting links');
    var links = collect();
    if (!links.length) throw USD.Err('notfound', 'This page has no links to follow.');
    ctx.total(links.length);
    await ctx.send({ t: 'ih:links', links: links, page: { url: location.href, title: document.title } });
    return links.length;
  };
})();
